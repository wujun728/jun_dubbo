#for (DBTable table : tables)
arp.addMapping(${table.className}.TABLE_NAME, ${table.className}.PRIMARY_KEY, ${table.className}.class);
#end