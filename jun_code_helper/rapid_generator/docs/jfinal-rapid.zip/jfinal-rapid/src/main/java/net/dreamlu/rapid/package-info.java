/**
 * 自动生成部分，脚手架，生成通用类
 * @author L.cm
 * email: 596392912@qq.com
 * site:http://www.dreamlu.net
 * @date 2014年9月10日 上午9:32:31
 */
package net.dreamlu.rapid;